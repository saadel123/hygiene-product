@extends('master')
@section('title', 'Rana')

@section('description', 'TEST')
@section('stylesheet')

@endsection

@section('content')
    @include('partials.categories-list')
    @include('partials.produits-list')

@endsection
