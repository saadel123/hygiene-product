<!--  Products Section -->
<section id="pricing" class="products">
    <div class="container" data-aos="fade-up">
        <div class="row gy-4" data-aos="fade-left">
            <?php
                $delay  = 200;
            ?>
            <?php if($category): ?>
                <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="<?php echo e($delay); ?>">
                        <div class="box">
                            <img src="<?php echo e(Voyager::image($product->image)); ?>" class="img-fluid"
                                alt="<?php echo e($product->{'title_' . app()->getLocale()}); ?>" />
                            <h3><?php echo e($product->{'title_' . app()->getLocale()}); ?></h3>
                            <a href="<?php echo e(url('produits/'. $category->slug . '/' . $product->slug)); ?>" class="btn-buy"><?php echo e(__('partials.buttons.see_more')); ?></a>
                        </div>
                    </div>
                    <?php
                        $delay  += 100;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- End Products Section -->
<?php /**PATH C:\xampp\htdocs\rana\resources\views\partials\produits-list.blade.php ENDPATH**/ ?>