
<?php $__env->startSection('title', 'Rana'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>
        .contact span {
            color: red;
            margin-left: 15px;
        }

        .page-qualite.qualite-bg {
            background-image: url('assets/img/satisfaction/slide-qualite.jpg');
        }

        .page-qualite {
            background-position: center center;
            background-size: cover;
            padding-top: 55px;
            padding-bottom: 55px;
            position: relative;
            z-index: 1;
            text-align: start;
            overflow: hidden;
            color: #ffffff;
        }

        .page-qualite::before {
            position: absolute;
            content: '';
            background: rgba(204, 15, 103, 0.6);
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
        }

        .qualite p {
            font-size: 20px;
        }

        .qualite h1 {
            margin-bottom: 20px;
            font-weight: 700;
        }

        .satisfaction-client h3 {
            margin: 0px 0 20px 0px;
            font-size: 34px;
            line-height: 42px;
            font-weight: 700;
            color: #305095;
        }

        .satisfaction-client p {
            font-size: 19px;
        }

        /* .environnement .bg-environnement {
                                        padding: 35px 0px 20px 65px;
                                        border-radius: 60px 0px 60px 0px;
                                        margin-left: 100px;
                                        margin-right: -35px;
                                        background: #07b228;
                                    }

                                    @media (max-width: 1000px) {
                                        .environnement p {
                                            max-width: 555px !important;
                                        }
                                    }

                                    .environnement p {
                                        margin: 15px 0 30px 0;
                                        line-height: 26px;
                                        max-width: 637px;
                                        font-size: 21px;
                                        color: #000;
                                    }

                                    .environnement h3 {
                                        color: white;
                                        font-weight: 600;
                                    } */
        .disponibilite .content {
            background-color: #305095;
            padding: 50px;
        }

        .disponibilite h3 {
            margin: 0px 0 21px 0px;
            font-size: 34px;
            line-height: 42px;
            font-weight: 700;
            color: #ffffff;
        }

        .disponibilite p {
            font-size: 20px;
            color: #fff;
        }

        .disponibilite img {
            max-width: 300px
        }

        @media (min-width: 1024px) {
            .disponibilite .col-lg-12 {
                padding: 0 50px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main">
        <section class="page-qualite qualite-bg qualite  mt-5" data-aos="fade-up">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-md-10">
                        <h1> <?php echo e(__('advantages.qualite.title')); ?> </h1>
                        <p>
                            <?php echo __('advantages.qualite.description'); ?>

                        </p>
                    </div>
                </div>
            </div>
        </section>
        <section class="mt-5 satisfaction-client">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-center">
                            <img src="<?php echo e(asset('assets/img/satisfaction/babble.jpg')); ?>" style="max-height: 500px;"
                                class="img-fluid" alt="<?php echo e(__('advantages.satisfaction.title')); ?>">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="col-md-12 aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
                            <h3><?php echo e(__('advantages.satisfaction.title')); ?></h3>
                            <p>
                                <?php echo __('advantages.satisfaction.description'); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="disponibilite">
            <div class="container" data-aos="fade-up">
                <div class="col-lg-12 d-flex flex-column" data-aos="fade-up" data-aos-delay="200">
                    <div class="content">
                        <div class="row">
                            <div class="col-lg-9">
                                <h3>
                                    <?php echo e(__('advantages.disponibilite.title')); ?>

                                </h3>
                                <p>
                                    <?php echo __('advantages.disponibilite.description'); ?>

                                </p>
                            </div>
                            <div class="col-lg-3">
                                <img src="<?php echo e(asset('assets/img/satisfaction/disponibilite.png')); ?>" class=""
                                    alt="<?php echo e(__('advantages.satisfaction.title')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\main\nos-atouts.blade.php ENDPATH**/ ?>