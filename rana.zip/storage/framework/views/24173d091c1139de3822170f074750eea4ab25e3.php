<?php $__env->startComponent('mail::message'); ?>
Bonjour

Vous avez un nouveau message de: <strong><?php echo e($details['nom']); ?></strong> <br>

<strong>Nom et Prenom:</strong> <?php echo e($details['nom'].' '.$details['prenom']); ?> <br>
<strong>Email:</strong> <?php echo e($details['email']); ?> <br>
<?php if(!empty($details['tele'])): ?>
<strong>Télephone:</strong> <?php echo e($details['tele']); ?> <br>
<?php endif; ?>
<strong>Adresse:</strong> <?php echo e($details['adresse']); ?> <br>

<strong>Message:</strong> <?php echo e($details['message']); ?><br><br>

Cordialement,<br>
L'équipe<span> </span>Rana.
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\rana\resources\views\emails\ContactUs.blade.php ENDPATH**/ ?>