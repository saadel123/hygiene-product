
<?php $__env->startSection('title', 'Rana'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>
        /* .blog .img-fluid {
                        max-height: 300px;
                    } */

        .blog p {
            white-space: pre-line;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======= Blog Single Section ======= -->
    <!-- ======= Blog Single Section ======= -->
    <section id="blog" class="blog">
        <div class="container" data-aos="fade-up">

            <div class="row">

                <div class="col-lg-8 entries">

                    <article class="entry entry-single">

                        <div class="entry-img">
                            <img src="<?php echo e(Voyager::image($blog->image)); ?>" alt="<?php echo e($blog->title); ?>" class="img-fluid">
                        </div>

                        <h2 class="entry-title">
                            <?php echo e($blog->title); ?>

                        </h2>

                        <div class="entry-meta">
                            <ul>
                                <i class="bi bi-clock"></i>
                                <time>
                                    <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?>

                                </time>
                                </li>
                            </ul>
                        </div>

                        <div class="entry-content">
                            <p>
                                <?php echo $blog->body; ?>

                            </p>
                        </div>

                    </article><!-- End blog entry -->
                </div><!-- End blog entries list -->

                <div class="col-lg-4">
                    <div class="sidebar">
                        <h3 class="sidebar-title">Les dernières blogs</h3>
                        <div class="sidebar-item recent-posts">
                            <?php $__currentLoopData = $relatedBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="post-item clearfix">
                                    <img src="<?php echo e(Voyager::image($relatedBlog->image)); ?>" alt="">
                                    <h4><a href="<?php echo e(route('blogs.show', $relatedBlog->slug)); ?>"> <?php echo e($relatedBlog->title); ?></a></h4>
                                    <time datetime="2020-01-01">
                                        <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?></time>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div><!-- End sidebar recent posts-->

                    </div><!-- End sidebar -->

                </div><!-- End blog sidebar -->
            </div>
        </div>
    </section><!-- End Blog Single Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\blog\details-blog.blade.php ENDPATH**/ ?>