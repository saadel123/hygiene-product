<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-block text-center">
        <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>
<?php if($message = Session::get('danger')): ?>
    <div class="alert alert-success alert-block text-center">
        <strong><?php echo e($message); ?></strong>
    </div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\rana\resources\views\partials\messages-alert.blade.php ENDPATH**/ ?>