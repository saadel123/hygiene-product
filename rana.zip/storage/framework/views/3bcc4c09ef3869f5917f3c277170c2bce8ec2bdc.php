<section id="category" class="category">
    <div class="container" data-aos="fade-up">
        <div class="col-lg-12 d-flex flex-column">
            <div class="row gy-4 text-center align-items-center justify-content-center">
                <?php
                    $i = 200;
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-12" data-aos="fade-up" data-aos-delay="<?php echo e($i); ?>">
                        <a href="<?php echo e(route('produits.show', $categorie->slug)); ?>"
                            class="category-btn d-md-block <?php echo e(request()->is('produits/' . $categorie->slug . '*') ? 'active' : ''); ?>">
                            <div class=" title">
                                <h4><?php echo e($categorie->{'name_'.app()->getLocale()}); ?></h4>
                            </div>
                        </a>
                    </div>
                    <?php
                        $i += 100;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\rana\resources\views\partials\categories-list.blade.php ENDPATH**/ ?>