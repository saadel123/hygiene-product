<input type="color" class="form-control" name="<?php echo e($row->field); ?>"
       value="<?php echo e(old($row->field, $dataTypeContent->{$row->field})); ?>">
<?php /**PATH C:\xampp\htdocs\rana\vendor\tcg\voyager\resources\views\formfields\color.blade.php ENDPATH**/ ?>