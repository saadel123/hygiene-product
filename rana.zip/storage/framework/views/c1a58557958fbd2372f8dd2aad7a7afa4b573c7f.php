<div class="col-md-6">
    <label for="nom" class="form-label"><?php echo e(__('partials.forms.contact.l_name')); ?>*</label>
    <input type="text" name="nom" id="nom" class="form-control <?php echo e($errors->has('nom') ? 'is-invalid' : ''); ?>"
        value="<?php echo e(old('nom')); ?>"  />
    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="col-md-6">
    <label for="prenom" class="form-label"><?php echo e(__('partials.forms.contact.f_name')); ?>*</label>
    <input type="text" name="prenom" id="prenom"
        class="form-control <?php echo e($errors->has('prenom') ? 'is-invalid' : ''); ?>" value="<?php echo e(old('prenom')); ?>"  />
    <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="col-md-6">
    <label for="number" class="form-label"><?php echo e(__('partials.forms.contact.phone')); ?>*</label>
    <input type="number" id="number" class="form-control <?php echo e($errors->has('tele') ? 'is-invalid' : ''); ?>"
        name="tele" value="<?php echo e(old('tele')); ?>"  />
    <?php $__errorArgs = ['tele'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="col-md-6">
    <label for="email" class="form-label"><?php echo e(__('partials.forms.contact.email')); ?>*</label>
    <input type="email" id="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
        name="email" value="<?php echo e(old('email')); ?>"  />
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="col-md-12">
    <label for="adresse" class="form-label"><?php echo e(__('partials.forms.contact.address')); ?>*</label>
    <input type="text" id="adresse" class="form-control <?php echo e($errors->has('adresse') ? 'is-invalid' : ''); ?>"
        name="adresse" value="<?php echo e(old('adresse')); ?>"  />
    <?php $__errorArgs = ['adresse'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\xampp\htdocs\rana\resources\views\partials\contact-form.blade.php ENDPATH**/ ?>