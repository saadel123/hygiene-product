
<?php $__env->startSection('title', 'Distribution'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>
        .contact span {
            color: red;
            margin-left: 15px;
        }

        .bg-distribution {
            background: rgb(3, 157, 217);
            background: radial-gradient(circle, rgba(3, 157, 217, 1) 0%, rgba(12, 81, 156, 1) 100%);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .form-control {
            border: 1px solid #a29191 !important;
        }

        .distribution .php-email-form {
            background: unset !important;
            /* padding: 30px;
                    height: 100%; */
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= Contact Section ======= -->
        <section id="distribution" class="distribution">
            <div class="container" data-aos="fade-up">
                <header class="section-header text-start">
                    <h1>Distribution</h1>
                </header>
                <div class="row gy-4">
                    <p>Notre flotte comporte une variété de formats de véhicules permettant de distribuer les marchandises
                        dans tout le Royaume.</p>
                    <div class="col-lg-12 col-md-12 d-flex align-items-center justify-content-center" data-aos="fade-up"
                        data-aos-delay="200">
                        <img src="<?php echo e(asset('assets/img/distribustion/distribustion.jpg')); ?>" class=""
                            alt="distribution">
                    </div>
                </div>
            </div>
        </section>
        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact distribution">
            <div class="" data-aos="fade-up">
                <div class="row gy-4">
                    <div class="col-lg-5 bg-distribution">
                        <img src="<?php echo e(asset('assets/img/distribustion/distribustion-products.png')); ?>" class=""
                            style="max-height: 450px;" alt="distribution">
                    </div>
                    <div class="col-lg-5">
                        <form action="<?php echo e(route('contact.store')); ?>" method="post" class="php-email-form">
                            <?php echo $__env->make('partials.messages-alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row gy-4">
                                <?php echo $__env->make('partials.contact-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="col-md-12">
                                    <label for="ville" class="form-label"><?php echo e(__('partials.forms.contact.ville')); ?>*</label>
                                    <select class="form-select" name="ville" id=""
                                        aria-label="Default select example">
                                        <option selected>Open this select menu</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label for="ville" class="form-label"><?php echo e(__('partials.forms.contact.requested_products')); ?>*</label>
                                    <select class="form-select" name="ville" id=""
                                        aria-label="Default select example">
                                        <option selected>Open this select menu</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                        <option value="4">Four</option>
                                        <option value="5">Hello Which kind of post you want</option>
                                        Thanks mate will do the same for the flyer
                                    </select>
                                </div>
                                <div class="col-md-12">
                                    <label for="adresse" class="form-label"><?php echo e(__('partials.forms.contact.message')); ?>*</label>
                                    <textarea class="form-control <?php echo e($errors->has('message') ? 'is-invalid' : ''); ?>" name="message" rows="6"
                                        placeholder="Message" required> <?php echo e(old('message')); ?></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit"><?php echo e(__('partials.buttons.send')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-2">
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Section -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\main\distribution.blade.php ENDPATH**/ ?>