
<?php $__env->startSection('title', 'Rana'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>
        .blog .img-fluid {
            max-height: 300px;
        }

        .blog .blog-pagination a,
        .blog .blog-pagination span {
            border-radius: 50% !important;
            margin: 0 5px !important;
            padding: 7px 16px;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <main id="main">


        <!-- ======= Blog Section ======= -->
        <section id="blog" class="blog">
            <div class="container" data-aos="fade-up">
                <div class="row">
                    <div class="col-lg-12 entries">
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row entry">
                                <div class="col-md-4">
                                    
                                    <div class="">
                                        <img src="<?php echo e(Voyager::image($blog->image)); ?>" alt="<?php echo e($blog->title); ?>"
                                            class="img-fluid">
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h2 class="entry-title">
                                        <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                                    </h2>
                                    <div class="entry-meta">
                                        <ul>
                                            <i class="bi bi-clock"></i>
                                            <time>
                                                <?php echo e(\Carbon\Carbon::parse($blog->created_at)->format('d/m/Y')); ?>

                                            </time>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="entry-content">
                                        <p>
                                            <?php echo Str::limit($blog->body, 320, '...'); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="blog-pagination">
                            <ul class="justify-content-center">
                                <li><?php echo $blogs->links(); ?></li>
                            </ul>
                        </div>
                    </div><!-- End blog entries list -->
                </div>
            </div>
        </section><!-- End Blog Section -->
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\blog\blogs.blade.php ENDPATH**/ ?>