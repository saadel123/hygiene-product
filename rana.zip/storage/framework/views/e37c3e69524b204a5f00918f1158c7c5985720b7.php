
<?php $__env->startSection('title', 'Rana'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main">
        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact">
            <div class="container" data-aos="fade-up">
                <header class="section-header">
                    <h1><?php echo e(__('partials.navbar.contact')); ?></h1>
                </header>
                <div class="row gy-4">
                    
                    <div class="col-lg-12">
                        <form action="<?php echo e(route('contact.store')); ?>" method="post" class="php-email-form">
                            <?php echo $__env->make('partials.messages-alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row gy-4">
                                <?php echo $__env->make('partials.contact-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="col-md-12">
                                    <label for="message" class="form-label"><?php echo e(__('partials.forms.contact.message')); ?>*</label>
                                    <textarea class="form-control <?php echo e($errors->has('message') ? 'is-invalid' : ''); ?>" name="message" id="message"
                                        rows="6" required> <?php echo e(old('message')); ?></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 text-center">
                                    <button type="submit"><?php echo e(__('partials.buttons.send')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Contact Section -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\main\contact.blade.php ENDPATH**/ ?>