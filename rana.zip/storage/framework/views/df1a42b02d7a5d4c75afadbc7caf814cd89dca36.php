
<?php $__env->startSection('title', 'Rana'); ?>

<?php $__env->startSection('description', 'TEST'); ?>
<?php $__env->startSection('stylesheet'); ?>
    <style>
        .product-detail .ratings {
            margin-right: 10px;
            color: #fbc634;
        }

        .product-detail .ratings i {

            color: #fbc634;
            font-size: 30px;
        }

        .product-detail .img-thumbnail {
            padding: 7.25rem;
            background-color: #fff;
            border: 3px solid var(--bs-border-color);
            border-radius: 3rem;
            max-width: 100%;
            width: 65%;
            height: auto;
        }

        .product-detail .btn-achtez {
            font-family: "Roboto", sans-serif;
            font-weight: 400;
            font-size: 25px;
            letter-spacing: 1px;
            display: inline-block;
            padding: 10px 55px;
            border-radius: 50px;
            border: unset;
            transition: 0.5s;
            line-height: 1;
            -webkit-animation-delay: 0.8s;
            animation-delay: 0.8s;
            background: linear-gradient(0deg, rgba(127, 5, 148, 1) 0%, rgba(165, 13, 194, 1) 100%);
            color: #fff;
        }

        .product-detail .uses-text {
            color: #305095;
            font-size: 18px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.categories-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ======= Products Section ======= -->
    <section class="product padding-y bg-white product-detail">
        <div class="container" data-aos="fade-up">
            <div class="row">
                <aside class="col-lg-6">
                    <article class="gallery-wrap d-flex">
                        <div class="img-big-wrap text-center mx-auto img-thumbnail">
                            <img class="" src="<?php echo e(Voyager::image($product->image)); ?>"
                                style="max-width: 110px; height: auto;">
                        </div>
                    </article>
                </aside>
                <div class="col-lg-6">
                    <article class="ps-lg-3">
                        <header class="section-header">
                            <h1 class="fw-bold"><?php echo e($product->{'title_' . app()->getLocale()}); ?></h1>
                            <span class="uses-text"><?php echo e($product->{'uses_' . app()->getLocale()}); ?></span>
                        </header>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="ratings">
                                <?php for($i = 0; $i < 5; $i++): ?>
                                    <i class="bi bi-star<?php echo e($i < $product->stars ? '-fill rating-color' : ''); ?>"></i>
                                <?php endfor; ?>
                            </div>
                            
                        </div>
                        <div class="mb-3"> <span class="price h5"><?php echo e($product->prix); ?> MAD</span> <span
                                class="text-muted">/<?php echo e($product->{'size_' . app()->getLocale()}); ?></span>
                        </div>
                        <p><?php echo $product->{'description_' . app()->getLocale()}; ?></p>
                        <p>
                            <strong><?php echo e(__('partials.info.instructions')); ?></strong>
                            <?php echo e($product->{'mode_emploi_' . app()->getLocale()}); ?>

                        </p>
                        <p>
                            <strong><?php echo e(__('partials.info.caution')); ?></strong>
                            <?php echo e($product->{'precaution_emploi_' . app()->getLocale()}); ?>

                        </p>

                        
                        <div class="mt-5">
                            <a href="<?php echo e(url('/distribution')); ?>" class="btn btn-warning btn-achtez animate__animated animate__fadeInUp">
                                <?php echo e(__('partials.buttons.buy')); ?>

                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section id="pricing" class="products">
        <div class="container" data-aos="fade-up">
            <div class="row gy-4" data-aos="fade-left">
                <?php
                    $i = 200;
                ?>
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="<?php echo e($i); ?>">
                        <div class="box">
                            <img src="<?php echo e(Voyager::image($product->image)); ?>" class="img-fluid"
                                alt="<?php echo e($product->{'title_' . app()->getLocale()}); ?>" />
                            <h3><?php echo e($product->{'title_' . app()->getLocale()}); ?></h3>
                            <a href="<?php echo e(url('produits/' . $name_cat . '/' . $product->slug)); ?>" class="btn-buy"><?php echo e(__('partials.buttons.see_more')); ?></a>
                        </div>
                    </div>
                    <?php
                        $i += 100;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rana\resources\views\products\details-produit.blade.php ENDPATH**/ ?>